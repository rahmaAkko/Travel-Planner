import java.util.Date;

public class Reservation {
    private int reservationNumber;
    private Date reservationDate;
    private User user;
    private Payment payment;

    ////////////// SETTER & GETTER //////////////


    public int getReservationNumber() {
        return reservationNumber;
    }
    public void setReservationNumber(int reservationNumber) {
        this.reservationNumber = reservationNumber;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }

    public Date getReservationDate() {
        return reservationDate;
    }
    public void setReservationDate(Date reservationDate) {
        this.reservationDate = reservationDate;
    }

    public User getUser() {

        return user;
    }
    public void setUser(User user) {

        this.user = user;
    }
    ////////////// METHODS ///////////////
    public Reservation(int reservationNumber, Date reservationDate, User user) {
        this.reservationNumber = reservationNumber;
        this.reservationDate = reservationDate;
        this.user = user;
    }
    public void displayReservationInfo(){
        System.out.println("Reservation 1:");
        System.out.println("Reservation Number: " + reservationNumber);
        System.out.println("Reservation Date: " + reservationDate);
        System.out.println("Travel Plane Details: ");

        }



}
