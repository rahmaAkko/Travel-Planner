import java.util.ArrayList;
import java.util.List;

public class RoadSteps {
    private List<String> steps;

    // Constructor
    public RoadSteps() {
        this.steps = new ArrayList<>();
    }

    // Add a step to the road steps- setter
    public void addStep(String step) {
        steps.add(step);
    }

    // Get all steps-getter
    public List<String> getSteps() {
        return steps;
    }

    ///// Set a specific step with the given details-////constructor
    public void setRoadStep(int stepNo, String departure, String destination, String transport) {
        if(stepNo >= 0 && stepNo < steps.size()) {
            steps.set(stepNo, "Step " + (stepNo + 1) + ": Going from " + departure + " to " + destination + " by " + transport);
        } else {
            System.out.println("Invalid step number.");
        }
    }
    public void displaySteps() {
        System.out.println("Travel Road Steps:");
        for (int i = 0; i < steps.size(); i++) {
            System.out.println(steps.get(i));
        }
    }

    // Main method for testing
//    public static void main(String[] args) {
//        RoadSteps roadSteps = new RoadSteps();
//        roadSteps.addStep("Initial step");
//        roadSteps.addStep("Another step");
//
//        roadSteps.setRoad`Step(0, "Istanbul", "Ankara", "train");
//        roadSteps.setRoadStep(1, "Ankara", "Izmir", "plane");
//
//        roadSteps.displaySteps();
//    }
}
