public class Notification {
    private int notificationId;
    private String message;
    private User user;

////////////// SETTER & GETTER //////////////

    public int getNotificationId() {
        return notificationId;
    }
    public void setNotificationId(int notificationId) {
        this.notificationId = notificationId;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public User getUser() {
        return user;
    }
    public void setUser(User user) {
        this.user = user;
    }

////////////// METHODS ///////////////

    public Notification(int notificationId, String message, User user) {
        this.notificationId = notificationId;
        this.message = message;
        this.user = user;
    }

}
