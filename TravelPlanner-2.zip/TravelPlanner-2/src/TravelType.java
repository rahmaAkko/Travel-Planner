import java.util.Arrays;

public class TravelType {
    private String travelType;

    ////////////// SETTER & GETTER //////////////

    public String getTravelType() {
        return travelType;
    }
    public void setTravelType(String travelType) {
        this.travelType = this.travelType;
    }

    ////////// METHODS ////////////////

    public TravelType(String travelType) {
        this.travelType = travelType;
    }




}
