import java.util.ArrayList;
import java.util.List;

public abstract class TravelRoad {

    private String Country;
    private String City;
    private String departure;
    private String destination;
    private List<String> roadSteps;

    ///////////// SETTER & GETTER ///////////

    public void setCountry(String Country){
        this.Country =  Country;
    }
    public String getCountry(){
        return Country;
    }

    public void setCity(String city){
        this.City = city;
    }
    public String getCity(){
        return City;
    }

    public String getDeparture() {
        return departure;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public String getDestination() {
        return destination;
    }

    public void setTravelDestination(String destination) {
        this.destination = destination;
    }

    //////////// METHODS ///////////////

    public TravelRoad(){

    }

    public TravelRoad( String departure, String destination) {
        this.departure = departure;
        this.destination = destination;
    }
    public void setTravelDestination(String departure, String destination) {
        this.departure = departure;
        this.destination = destination;
    }
    public void displayTravelRoadInfo() {
        System.out.println("Departure : " + departure);
        System.out.println("Destination : " + destination);
    }

    abstract void ShowTheRoadOnMap(String departure, String destination);


}
