import java.util.ArrayList;
import java.util.Arrays;


public class TravelPlan extends TravelRoad implements Itinerary{
    private int TravelNo;
    private String startDate;
    public String endDate;
    private String Time;
    private TravelType travelType;
    private Travelers traveler;
    private User user;
    private Transport transport;
    private boolean InsideTurkey;
    private ArrayList<String> Activities;
    private RoadSteps roadSteps;


///////////////       SETTER & GETTER      /////////////

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public RoadSteps getRoadSteps() {
        return roadSteps;
    }

    public void setRoadSteps(RoadSteps roadSteps) {
        this.roadSteps = roadSteps;
    }

    public Travelers getTraveler() {
        return traveler;
    }

    public void setTraveler(Travelers traveler) {
        this.traveler = traveler;
    }

    public void setInsideTurkey(boolean insideTurkey) {
        InsideTurkey = insideTurkey;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public void setTravelNo(int travelNo) {
        TravelNo = travelNo;
    }

    public int getTravelNo() {
        return TravelNo;
    }

    public TravelType getTravelType() {
        return travelType;
    }

    public void setTravelType(TravelType travelType) {
        this.travelType = travelType;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setTransport(Transport transport) {
        this.transport = transport;
    }

    public Transport getTransport() {
        return transport;
    }

    ////////////////     METHODS /////////////////
    public TravelPlan(){
        roadSteps = new RoadSteps();
    }

    public TravelPlan(User user, TravelType travelType, String startDate, String time, String destination) {
        setTravelDestination(destination);
        this.travelType = travelType;
        this.user = user;
        this.startDate = startDate;
        Time = time;
        roadSteps = new RoadSteps();
        user.addTravelPlan(this);
    }

    public TravelPlan(User user, String startDate, String time, TravelType travelType) {
        this.user = user;
        this.travelType = travelType;
        this.startDate = startDate;
        Time = time;
        roadSteps = new RoadSteps();
        user.addTravelPlan(this);
    }
    /// Travel plan information form
    @Override
    public void DisplayInfo() {
        System.out.println("    Type: " + travelType.getTravelType());
        System.out.println("   from Date: " + startDate);
        if(endDate == null) {
            System.out.println("   till Date: " + "not specified");
        }else{
            System.out.println("   till Date: " + endDate);
        }
        System.out.println(" from " + getDeparture());
        System.out.println(" to : " + getDestination());
    }

    //// setting trip activities

    @Override
    public void addActivity(String Activity, String time) {
        Activities.add(Activity);
    }
    @Override
    public void removeActivity(String Activity) {
        Activities.remove(Activity);

    }

    @Override
    public void DisplayActivity() {
        System.out.println(Activities);

    }

    @Override
    public void findRestaurant(Travelers travelers) {
        System.out.println("The resturant near by are : ");
    }
    @Override
    public void findHospitals(String disease) {
        System.out.println("The best hospitals for caring "+ disease +" you can find in " + getDestination() + "are :");
        System.out.println(" ");
    }
    @Override
    public void getTicket(int TransportNo){

    }
    @Override
    void ShowTheRoadOnMap(String departure, String destination) {
        System.out.println("showing the road on map from "+ departure +" to " + destination);
    }


///// here are lists of countries & cities for every TravelType I defined in the main class


    ///// OUTSIDE TURKEY

    public static String[] BusinessCountries = new String[]
            {"Germany", "London", "Singapore"}; //Example Countries
    public static String[] AdventureCountries = new String[]
            {"Australia", "Argentina", "New Zealand"};
    public static String[] WinterSportsCountries = new String[]
            {"France", "Switzerland", "Canada"};
    public static String[] SportEventCountries = new String[]
            {"Spain", "England", "India"};//The Countries that present sport events at this time
    public static String[] MedicalCountries = new String[]
            {"India", "Singapore", "Thailand"};
    public static String[] BeachCountries = new String[]
            {"Maldives", "Seychelles", "Australia"};
    public static String[] CulturalCountries = new String[]
            {"Italy", "Greece", "Japan"};
    public static String[] HolidayCountries = new String[]
            {"Barcelona", "Greece", "Bali"};


    public void getTypeCountries(TravelType travelType) {
        switch (travelType.getTravelType()) {
            case "Beach":
                System.out.println(Arrays.toString(TravelPlan.BeachCountries));
                break;
            case "Medical":
                System.out.println(Arrays.toString(TravelPlan.MedicalCountries));
                break;
            case "Adventure":
                System.out.println(Arrays.toString(TravelPlan.AdventureCountries));
                break;
            case "Business":
                System.out.println(Arrays.toString(TravelPlan.BusinessCountries));
                break;
            case "Culture":
                System.out.println(Arrays.toString(TravelPlan.CulturalCountries));
                break;
            case "WinterSports":
                System.out.println(Arrays.toString(TravelPlan.WinterSportsCountries));
                break;
            case "SportEvent":
                System.out.println(Arrays.toString(TravelPlan.SportEventCountries));
                break;
            case "Holiday":
                System.out.println(Arrays.toString(TravelPlan.HolidayCountries));
                break;
        }
    }
    ///// INSIDE TURKEY

    public static String[] BusinessTowns = new String[]
            {"Istanbul", "Bursa", "Ankara"}; //Example Countries
    public static String[] AdventureTowns = new String[]
            {"Amasya", "Bozcaada", "Göreme"};
    public static String[] WinterSportsTowns = new String[]
            {"Bursa-Uludağ", "Istanbul-Palandöken", "Kayseri-Erciyes"};
    public static String[] SportEventTowns = new String[]
            {"Termal", "Antalya", "Manisa"};//The Countries that present sport events at this time
    public static String[] MedicalTowns = new String[]
            {"Yalova", "Kayseri", "Eskişehir"};
    public static String[] BeachTowns = new String[]
            {"Fethiye", "Antalya", "Bodrum"};
    public static String[] CulturalTowns = new String[]
            {"Istanbul", "Urfa", "Mardın"};
    public static String[] HolidayTowns = new String[]
            {"Antalya", "Bodrum", "Istanbul"};

    public void getTypeTowns(TravelType travelType) {
        switch (travelType.getTravelType()) {
            case "Beach":
                System.out.println(Arrays.toString(TravelPlan.BeachTowns));
                break;
            case "Medical":
                System.out.println(Arrays.toString(TravelPlan.MedicalTowns));
                break;
            case "Adventure":
                System.out.println(Arrays.toString(TravelPlan.AdventureTowns));
                break;
            case "Business":
                System.out.println(Arrays.toString(TravelPlan.BusinessTowns));
                break;
            case "Culture":
                System.out.println(Arrays.toString(TravelPlan.CulturalTowns));
                break;
            case "WinterSports":
                System.out.println(Arrays.toString(TravelPlan.WinterSportsTowns));
                break;
            case "SportEvent":
                System.out.println(Arrays.toString(TravelPlan.SportEventTowns));
                break;
            case "Holiday":
                System.out.println(Arrays.toString(TravelPlan.HolidayTowns));
                break;
        }
    }


}
