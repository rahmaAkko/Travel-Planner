import java.util.ArrayList;


public class User {
    private String firstName;
    private String lastName;
    private int age;
    private String email;
    private String password;
    private TravelPlan trips;
    private ArrayList<TravelPlan> travelPlans;

    ///////////         SETTER & GETTER      /////////////

    public void setPassword(String password) {this.password = password;}
    public String getPassword() {
        return password;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setLastName(String lastName){
        this.lastName = lastName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getEmail() {
        return email;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public int getAge() {
        return age;
    }
    public void setTrips(TravelPlan trips) {
        this.trips = trips;
    }
    public TravelPlan getTrips() {
        return trips;
    }

    ///////////// METHODS //////////////

    public User(String firstName, String lastName, int age, String email, String password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.email = email;
        this.password = password;
        this.travelPlans = new ArrayList<>();
    }
    public void logIn(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public User(String firstName, String lastName, String email, String password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.travelPlans = new ArrayList<>();
    }
    public User(){
        this.travelPlans = new ArrayList<>();
    }

    public void addTravelPlan(TravelPlan plan) {
        travelPlans.add(plan);
    }
    public void removePlan(TravelPlan plan){
        travelPlans.remove(plan);
    }
    public void displayUserInfo(){
        System.out.println("User Details: ");
        System.out.println("    First Name: " + firstName);
        System.out.println("    Last Name: " + lastName);
        System.out.println("    Age: " + age);
    }
    public void displayAllTravelPlansForUser(){
        System.out.println("Travel Plans for "+firstName+" "+lastName +" : ");
        int i=0;
        for(TravelPlan plan : travelPlans){
            i++;
            System.out.println("Plan " + i + " :");
            plan.DisplayInfo();
        }
    }



}



