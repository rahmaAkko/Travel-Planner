import java.util.ArrayList;
import java.util.List;

public class Transport extends TravelRoad {
    private String transportName;
    private String transportNo;
    private String transportDate;
    private double cost;
    private String departureTime;
    private String arriveTime;
    private double speed;
    private String timeItTakes;
    private Reservation travelReservation;
    private int availableSeats;
    ;
    private String company;


    /////////// SETTER & GETTER ////////////////


    public String getTransportNo() {
        return transportNo;
    }

    public void setTransportNo(String transportNo) {
        this.transportNo = transportNo;
    }

    public String getTransportDate() {
        return transportDate;
    }

    public void setTransportDate(String transportDate) {
        this.transportDate = transportDate;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public String getArriveTime() {
        return arriveTime;
    }

    public void setArriveTime(String arriveTime) {
        this.arriveTime = arriveTime;
    }

    public String getTransportName(){
        return transportName;
    }
    public void setTransportName(String transportName) {
        this.transportName = transportName;
    }
    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }


    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public String getTimeItTakes() {
        return timeItTakes;
    }

    public void setTimeItTakes(String timeItTakes) {
        this.timeItTakes = timeItTakes;
    }

    public Reservation getTravelReservation() {
        return travelReservation;
    }

    public void setTravelReservation(Reservation travelReservation) {
        this.travelReservation = travelReservation;
    }

    public double getCost() {
        return cost;
    }
    public void setCost(double cost) {
        this.cost = cost;
    }
///////////// METHODS //////////////                               ///////////////

    public Transport() {}

    public Transport(String transportName, double cost, String departureTime) {
        this.transportName = transportName;
        this.cost = cost;
        this.departureTime = departureTime;
    }
    public Transport(String departure, String destination){
        super.setTravelDestination(departure, destination);
    }

    public Transport(String transportNo, String departure,String destination,String transportDate,String departureTime, String arriveTime) {
        super.setTravelDestination(departure, destination);
        this.transportNo = transportNo;
        this.departureTime = departureTime;
        this.arriveTime = arriveTime;
        this.transportDate = transportDate;
    }



    @Override
    void ShowTheRoadOnMap(String departure, String destination) {
        System.out.println("showing the road on map from " + departure + " to " + destination + " by " + transportName);
    }

}//////////// TransPorts
////////////Flight
class Flights extends Transport {
    private List<Transport> flights;
    public Flights() {
        this.flights = new ArrayList<>();
    }

    public void addFlights(String transportNo, String departure, String destination,String transportDate, String departureTime, String arrivalTime) {
        Transport flight = new Transport(transportNo, departure, destination, transportDate, departureTime, arrivalTime);
        flights.add(flight);
    }

    public List<Transport> findFlights(String departure, String destination) {
        List<Transport> matchingFlights = new ArrayList<>();
        for (Transport flight : flights) {
            if (flight.getDeparture().equals(departure) && flight.getDestination().equals(destination)) {
                matchingFlights.add(flight);
            }
        }
        return matchingFlights;
    }

}
/////////////////Train
class Trains extends Transport{
    private List<Transport> Trains;
    public void addTrain(String transportNo, String departure, String destination, String transportDate, String departureTime, String arrivalTime) {
        Transport train = new Transport(transportNo, departure, destination, transportDate,departureTime, arrivalTime);
        Trains.add(train);
    }

    public List<Transport> findTrainsWithDate(String departure, String destination,String transportDate) {
        List<Transport> matchingTrains = new ArrayList<>();
        for (Transport train : Trains) {
            if (train.getDeparture().equals(departure) && train.getDestination().equals(destination) && train.getTransportDate().equals(transportDate)) {
                matchingTrains.add(train);
            }
        }
        return matchingTrains;
    }

}
////////////////Bus
class Busses extends Transport{
    private List<Transport> busses;

    public Busses() {
        super(null, null, null, null, null, null); // Call to super is necessary, although fields are not used in Busses itself
        this.busses = new ArrayList<>();
    }

    public void addBusses(String transportNo, String departure, String destination, String transportDate, String departureTime, String arrivalTime) {
        Transport bus = new Transport(transportNo, departure, destination,transportDate, departureTime, arrivalTime);
        busses.add(bus);
    }

    public List<Transport> findBussesWithDate(String departure, String destination, String transportDate) {
        List<Transport> matchingBusses = new ArrayList<>();
        for (Transport bus : busses) {
            if (bus.getDeparture().equals(departure) && bus.getDestination().equals(destination) && bus.getTransportDate().equals(transportDate)) {
                matchingBusses.add(bus);
            }
        }
        return matchingBusses;
    }



}
