public class PasswordValidator {
    private static final int MIN_LENGTH = 6;
    private static final int MAX_LENGTH = 20;
    private static boolean containsDigit;
    private static boolean containsLetter;
    private static boolean Length;

    public static boolean isValidPassword(String password) {
        if(password == null || password.length() < MIN_LENGTH || password.length() > MAX_LENGTH){
            System.out.println("Password should be between " + MIN_LENGTH + " and " + MAX_LENGTH);
        }else{
            Length = true;
        }
        containsDigit = false;
        containsLetter = false;

        for (char c : password.toCharArray()) {
            if (Character.isDigit(c)) {
                containsDigit = true;
            }
            if (Character.isAlphabetic(c)) {
                containsLetter = true;
            }
        }
        if(!containsLetter){
            System.out.println("Password is invalid. Please make sure it contains at least one letter");
        }
        if(!containsDigit){
            System.out.println("Password is invalid. Please make sure it contains at least one digit");
        }

        return Length && containsLetter && containsDigit;
    }

}
