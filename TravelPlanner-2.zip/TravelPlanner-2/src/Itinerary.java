public interface Itinerary {


    void DisplayInfo();

    void addActivity(String Activity, String Time);

    void removeActivity(String Activity);

    void DisplayActivity();

    void findRestaurant(Travelers travelers);

    void findHospitals(String disease);

    void getTicket(int TransportNo);


}
