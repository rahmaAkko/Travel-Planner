import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class TravelPlanner {
    public static void main(String[] args) {


        //////// TravelType implement objects /////////////
        // here i will make the types & their hotels list

        //defining types
        TravelType Cultural = new TravelType("Cultural");
        TravelType Adventure = new TravelType("Adventure");
        TravelType Beach = new TravelType("Beach");
        TravelType Business = new TravelType("Business");
        TravelType WinterSport = new TravelType("WinterSports");
        TravelType SportEvent = new TravelType("SportEvent");
        TravelType Holiday = new TravelType("Holiday");
        TravelType Medical = new TravelType("Medical");


        ///////////////////////TRANSPORTS CHOICES/////////////////////////

        Busses busses = new Busses();
        busses.addBusses("AA123", "Kayseri", "Istanbul", "2024-06-01"," 08:00", "11:00");
        busses.addBusses("BA456", "Kayseri", "Manisa", "2024-06-01"," 09:00", "10:30");
        busses.addBusses("CA789", "Istanbul", "Manisa", "2024-06-03"," 10:00", "13:00");
        busses.addBusses("BA456", "Kayseri", "Manisa", "2024-06-04"," 04:00", "22:30");
        busses.addBusses("BA456", "Kayseri", "Manisa","2024-06-05", "1:00",  "19:30");

        //////////////////////TRAVELER TYPES///////////////////////
        Travelers family = new Travelers("family");
        Travelers couple = new Travelers("couple");
        Travelers friendGroup = new Travelers("friends group");
        Travelers businessGroup = new Travelers("business group");
        Travelers individual = new Travelers("individual");

        /////////////////////////////////////////////////

        //// making a users list to find the user by their email & password
        UserDatabase userDatabase = new UserDatabase();

        User user1 = new User("Melis", "Afifa", 20, "melis@gmail.com", "melis123");
        User user2 = new User("Rahmah", "Elkholy", 19, "rahmah@gmail.com", "rahmah123");

        userDatabase.addUser(user1);
        userDatabase.addUser(user2);

        // melis - im putting this so u can understand ur work up there
        TravelPlan plan1 = new TravelPlan(user1, Business, "2024-05-10", "10:00", "New York");
        TravelPlan plan2 = new TravelPlan(user2, Holiday, "2024-05-15", "15:00", "Paris");
        TravelPlan plan3 = new TravelPlan(user1, Medical, "2024-06-19", "16:00", "London");

        plan1.setDeparture("Istanbul");
        plan2.setDeparture("Egypt");
        plan3.setDeparture("Dubai");

        plan3.setEndDate("2024-06-26");


        // 000000





        //0000
//        Payment payment1 = new Payment(101, 500.0, "Credit Card", reservation1);
//        Payment payment2 = new Payment(102, 600.0, "PayPal", reservation2);

        //0000
//        System.out.println("\nPayment 1:");
//        System.out.println("Payment ID: " + payment1.getPaymentId());
//        System.out.println("Amount: " + payment1.getAmount());System.out.println("Payment Method: " + payment1.getPaymentMethod());
//        System.out.println("Related Reservation Number: " + payment1.getReservation().getReservationNumber());
//        //000
//        Notification notification1 = new Notification(201, "Your reservation is confirmed.", user1);
//        Notification notification2 = new Notification(202, "Your payment is successful.", user2);

        //000000
//        System.out.println("\nNotification 1:");
//        System.out.println("Notification ID: " + notification1.getNotificationId());
//        System.out.println("Message: " + notification1.getMessage());
//        System.out.println("Related User: " + notification1.getUser().getFirstName() + " " + notification1.getUser().getLastName());
//


        /////////0000/IMPLEMENTATION/0000/////////////
        System.out.println("welcome to Travel Planner");

        ////log in - sign up
        System.out.println("Dou you have an account ?");
        Scanner scanner = new Scanner(System.in);

        User user3 = new User();
        if (scanner.nextLine().equalsIgnoreCase("yes")) { //log in
            user3 = null;
            while (user3 == null) {
                System.out.println("Enter your email: ");
                String email = scanner.nextLine();

                System.out.println("Enter your password: ");
                String password = scanner.nextLine();

                user3 = userDatabase.findUser(email, password);

                if (user3 != null) {
                    System.out.println("User found: " + user3);
                } else {
                    System.out.println("Invalid email or password. Please try again.");
                }
            }

            System.out.println("Welcome back " + user3.getFirstName() + ",Do you want to review your trips or make a new one?");
            if (scanner.nextLine().equalsIgnoreCase("yes")) {
                user3.displayAllTravelPlansForUser();
            }

        } else { // sign up
            System.out.println("Enter your information to make a new account ! ");
            System.out.println("user first name : ");
            user3.setFirstName(scanner.nextLine());
            System.out.println("user last name : ");
            user3.setLastName(scanner.nextLine());
            System.out.println("user email : ");
            user3.setEmail(scanner.nextLine());
            System.out.println("user password : ");
            String password = scanner.nextLine();
            while (!PasswordValidator.isValidPassword(password)) {
                password = scanner.nextLine();
            }
            user3.setPassword(password);
            System.out.println("Age : ");
            user3.setAge(scanner.nextInt());
        }
        user3.displayUserInfo();

        System.out.println("Welcome " + user3.getFirstName() + ", Lets put a plan for your next trip!");

        ////// travel plan steps starts here
        //// 1-specify the travelType

        TravelPlan plan4 = new TravelPlan();
        plan4.setUser(user3);
        System.out.println(" What is your trip goal/Reason ?");
        System.out.println("Choices : Cultural - Adventure - Winter Sports - Business - Holiday - Medical - Sport Events - Beach");
        plan4.setTravelType(null);
        while (plan4.getTravelType() == null) {
            switch (scanner.nextLine()) {
                case "medical":
                    plan4.setTravelType(Medical);
                    break;
                case "sport event":
                    plan4.setTravelType(SportEvent);
                    break;
                case "business":
                    plan4.setTravelType(Business);
                    break;
                case "winter sports":
                    plan4.setTravelType(WinterSport);
                    break;
                case "adventure":
                    plan4.setTravelType(Adventure);
                    break;
                case "cultural":
                    plan4.setTravelType(Cultural);
                    break;
                case "holiday":
                    plan4.setTravelType(Holiday);
                    break;
                case "beach":
                    plan4.setTravelType(Beach);
                default:
                    System.out.println("this is not a valid option, please try again.");
                    break;
            }
        }

        //// specify the destination based on the travel type

        System.out.println("Where will you start the trip ? (example your home city /other trip end city)");
        plan4.setDeparture(scanner.nextLine());

        System.out.println("Do you have a specific destination ? (yes/no)");
        String answer = scanner.nextLine();
        switch (answer) {
            case "yes":
                System.out.println("Enter your destination : ");
                plan4.setTravelDestination(scanner.nextLine());
                break;
            case "no":
                System.out.println("Let us help you choose your destination !");
            if (plan4.getTravelType() == WinterSport || plan4.getTravelType() == SportEvent) {
                System.out.println("The places that are providing " + plan4.getTravelType().getTravelType() + " right now are:");
                System.out.println("Outside your country(Turkey):");
                plan4.getTypeCountries(plan4.getTravelType());
                System.out.println("Inside your country(Turkey):");
                plan4.getTypeTowns(plan4.getTravelType());
            } else {
                System.out.println("The " + plan4.getTravelType().getTravelType() + " countries you can go to are :");
                System.out.println("Outside your country(Turkey):");
                plan4.getTypeCountries(plan4.getTravelType());
                System.out.println("Inside your country(Turkey):");
                plan4.getTypeTowns(plan4.getTravelType());
            }
            System.out.println("choose one of them");
            plan4.setTravelDestination(scanner.nextLine());
                break;

        }

        ////// setting the dates of the trip
        System.out.println("Enter your trip start date :");
        plan4.setStartDate(scanner.nextLine());
        System.out.println("Enter your trip end date :");
        plan4.setEndDate(scanner.nextLine());

        ////// set up travelers
        System.out.println("Now for helping you book a transport ticket & hotel room, tell is who are the travelers ?");
        Travelers travelers = Travelers.createTravelerFromInput();
        System.out.println("Please choose Travelers Type : (Family / Couple / Friends Group / Business Group / individual)");
        travelers.setTravelerType(scanner.nextLine());
        System.out.println("How many member are there ?");
        travelers.setTravelersNumberCount(scanner.nextInt());
        plan4.setTraveler(travelers);

        ////// travel road -choose the transport based on date

        System.out.println("the available Transports form " + plan4.getDeparture() + " to " + plan4.getDestination());
        List<Transport> neededBusses = busses.findBussesWithDate(plan4.getDeparture(), plan4.getDestination(), plan4.getStartDate());
        for (Transport bus : neededBusses) {
            System.out.println(bus.toString());
        }
        RoadSteps roadSteps = new RoadSteps();
        plan4.setRoadSteps(roadSteps);
        System.out.println("What is the number of the transport you would like to go by ?");
        String n = scanner.nextLine();
        for(Transport bus : neededBusses){
            if(bus.getTransportNo().equals(n)){
                roadSteps.setRoadStep(2, bus.getDeparture(), bus.getDestination(), "bus");
            }else{
                System.out.println("invalid transport number, please try again.");
            }
        }

        Notification allowShareLocation = new Notification(200,"do you allow TravelPlanner to access your location ?",user3);
        System.out.println(allowShareLocation.toString());
        if(scanner.nextLine() == "yes"){
            System.out.println("You can go from your home/start station to departure station by : busses , car" +
                    "choose one of them to show you the road you will go by ");
            if(scanner.nextLine() == "car"){
                plan4.ShowTheRoadOnMap("home" , "Bus staion");
                roadSteps.setRoadStep(1,"home", "Bus staion", "car");
            } else if (scanner.nextLine() == "busses") {
                System.out.println("Showing available busses at the time");
                roadSteps.setRoadStep(1,"home", "Bus staion", "bus");
            }
        }
        

/////////////// reservation
        Date reservationDate1 = new Date();
        Date reservationDate2 = new Date();
        Reservation reservation1 = new Reservation(1, reservationDate1, user1);
        Reservation reservation2 = new Reservation(2, reservationDate2, user2);
        // Rezervasyonu oluşturun
        Date reservationDate = new Date(); // Şu anki tarih için
        Reservation reservation = new Reservation(1, reservationDate, user3);

        // Ödemeyi gerçekleştirin

        System.out.println("Enter payment amount:");
        double amount = Double.parseDouble(scanner.nextLine());

        System.out.println("Enter payment method (Credit Card/PayPal):");
        String paymentMethod = scanner.nextLine();

        Payment payment = new Payment(101, amount, "PayPal");
        // Bildirimi gönderin
        Notification notification = new Notification(201, "Your reservation is confirmed.", user3);



    }

}
