import java.util.Scanner;

public class Travelers {
    private String travelerType;
    private User plan; // Var olan User sınıfından bir nesne
    private String maritalStatus; // Single, Married
    private boolean isBusinessPerson; // İş insanı olup olmadığını belirlemek için
    private double budget; // Kullanıcının bütçesi
    private TravelType travelType; // Traveler type (Adventure, Family, Solo)
    private int stayDuration; // Konaklama süresi (gün olarak)
    private String specialNeeds; // Özel ihtiyaçlar (None, Disabled Access, Pet-Friendly, etc.)
    private String hotelType; // Otel tipi
    private int travelersNumberCount;// how many members

    // Constructor
    public Travelers( String maritalStatus, boolean isBusinessPerson, double budget, int stayDuration, String specialNeeds) {
        this.maritalStatus = maritalStatus;
        this.isBusinessPerson = isBusinessPerson;
        this.budget = budget;
        this.stayDuration = stayDuration;
        this.specialNeeds = specialNeeds;
        //this.hotelType = determineHotelType(); // Otel tipini belirleme
    }
    public Travelers(){

    }

    ///////// GETTER &  SETTER ///////////
    public User getPlan() {
        return plan;
    }

    public void setPlan(User plan) {
        this.plan = plan;
    }

    public void setTravelerType(String travelerType) {
        this.travelerType = travelerType;
    }

    public int getTravelersNumberCount() {
        return travelersNumberCount;
    }

    public void setTravelersNumberCount(int travelersNumberCount) {
        this.travelersNumberCount = travelersNumberCount;
    }

    public void setHotelType(String hotelType) {
        this.hotelType = hotelType;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
        //this.hotelType = determineHotelType(); // Yeni durum için otel tipini güncelle
    }

    public boolean isBusinessPerson() {
        return isBusinessPerson;
    }

    public void setBusinessPerson(boolean businessPerson) {
        isBusinessPerson = businessPerson;
        //this.hotelType = determineHotelType(); // Yeni durum için otel tipini güncelle
    }

    public double getBudget() {
        return budget;
    }

    public void setBudget(double budget) {
        this.budget = budget;
       // this.hotelType = determineHotelType(); // Yeni durum için otel tipini güncelle
    }

    public TravelType getTravelerType() {
        return travelType;
    }

    public void setTravelerType(TravelType travelerType) {
        this.travelType = travelerType;
        //this.hotelType = determineHotelType(); // Yeni durum için otel tipini güncelle
    }

    public int getStayDuration() {
        return stayDuration;
    }

    public void setStayDuration(int stayDuration) {
        this.stayDuration = stayDuration;
        //this.hotelType = determineHotelType(); // Yeni durum için otel tipini güncelle
    }

    public String getSpecialNeeds() {
        return specialNeeds;
    }

    public void setSpecialNeeds(String specialNeeds) {
        this.specialNeeds = specialNeeds;
        //this.hotelType = determineHotelType(); // Yeni durum için otel tipini güncelle
    }

    public String getHotelType() {
        return hotelType;
    }

///////// Özelliklere göre otel tipi belirleme

    public String determineHotelType(TravelType travelType) {
        switch (travelType.getTravelType()) {
            case "Business":
                return "Business Hotel";
            case "Beach":
                return "Hotel near the beach";
            case "Adventure":
                return "Adventure Lodge";
            case "Holiday":
                return "Holiday Hotel";
            case "Cultural":
                return "Hotel near the cultural places";
            case "WinterSports":
                return "Hotel near the Winter Sports";
            case "SportEvent":
                return "Hotels near the sport events";
            default:
                throw new IllegalArgumentException("Unknown travel type: " + travelType.getTravelType());
        }
    }

    public Travelers(String travelerType) {
        this.travelerType = travelerType;
    }

    public String determinedHotelFeatures() {

    switch (maritalStatus.toLowerCase()) {
        case "married":
            return "Luxury Hotel";

        case "single":
            return "Hostel";

        default:
            break;
    }

    if (budget < 100) {
        return "Budget Hotel";
    }

    if (stayDuration > 7) {
        return "Extended Stay Hotel";
    }

    switch (specialNeeds.toLowerCase()) {
        case "disabled access":
            return "Accessible Hotel";

        case "pet-friendly":
            return "Pet-Friendly Hotel";

        default:
            return "Standard Hotel";
    }
        
}

    // Traveler bilgilerini yazdırma
    public void displayTravelerDetails(TravelPlan plan) {
        System.out.println("Traveler Details:");
        System.out.println("    Name: " + plan.getUser().getFirstName() + " " + this.plan.getLastName());
        System.out.println("    Age: " + plan.getUser().getAge());
        System.out.println("    Email: " + this.plan.getEmail());
        System.out.println("    Marital Status: " + maritalStatus);
        System.out.println("    Business Person: " + (isBusinessPerson ? "Yes" : "No"));
        System.out.println("    Budget: " + budget);
        System.out.println("    Traveler Type: " + travelerType);
        System.out.println("    Stay Duration: " + stayDuration + " days");
        System.out.println("    Special Needs: " + specialNeeds);
        System.out.println("    Hotel Type: " + hotelType);
    }

    public static Travelers createTravelerFromInput() {
        Scanner scanner = new Scanner(System.in);

        // Kullanıcı bilgilerini alın

        System.out.println("Enter marital status (Single/Married):");
        String maritalStatus = scanner.nextLine();

        System.out.println("Is the user a business person? (yes/no):");
        boolean isBusinessPerson = scanner.nextLine().equalsIgnoreCase("yes");

        System.out.println("Enter budget:");
        double budget = Double.parseDouble(scanner.nextLine());

        System.out.println("Enter stay duration (in days):");
        int stayDuration = Integer.parseInt(scanner.nextLine());

        System.out.println("Enter special needs (None/Disabled Access/Pet-Friendly):");
        String specialNeeds = scanner.nextLine();


        // Seyahat eden kişiyi oluşturun

        return new Travelers( maritalStatus, isBusinessPerson, budget, stayDuration, specialNeeds);
    }

    // Özelliklere göre otel tipi belirleme - turkiyede

    private String determineHotelType(TravelPlan plan) {
        switch (plan.getTravelType().getTravelType().toLowerCase()) {
            case "business":
                return "Business Hotel: Radisson Blu Hotel Istanbul Pera, Hilton Istanbul Bomonti Hotel & Conference Center";

            case "family":
                return "Family Hotel: Rixos Premium Belek, Limak Lara Deluxe Hotel & Resort";

            case "adventure":
                return "Adventure Lodge: Club Med Palmiye, Nirvana Lagoon Villas Suites & Spa";

            default:
                break;
        }

        switch (maritalStatus.toLowerCase()) {
            case "married":
                return "Luxury Hotel: Çırağan Palace Kempinski, Four Seasons Hotel Istanbul at Sultanahmet";

            case "single":
                return "Hostel: Cheers Hostel Istanbul, Bahaus Hostel";

            default:
                break;
        }

        if (budget < 100) {
            return "Budget Hotel: Ibis Istanbul, Hotel Amira Istanbul";
        }

        if (stayDuration > 7) {
            return "Extended Stay Hotel: Radisson Residences Avrupa TEM Istanbul, Fraser Place Anthill Istanbul";
        }

        switch (specialNeeds.toLowerCase()) {
            case "disabled access":
                return "Accessible Hotel: Wyndham Grand Istanbul Levent, DoubleTree by Hilton Istanbul Topkapi";

            case "pet-friendly":
                return "Pet-Friendly Hotel: Swissotel The Bosphorus Istanbul, W Istanbul";

            default:
                return "Standard Hotel: Novotel Istanbul, Holiday Inn Istanbul City";
        }
    }


}